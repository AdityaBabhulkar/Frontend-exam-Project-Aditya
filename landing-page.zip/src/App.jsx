import React from "react"
import LandingPage from "./components/pages/LandingPage";
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {

  return (
    <div>
      <LandingPage />
    </div>
  )
}

export default App
